package com.geekcap.springintegrationexample.listener;

public interface MessageListener
{
    public void processMessage( String message );
}
