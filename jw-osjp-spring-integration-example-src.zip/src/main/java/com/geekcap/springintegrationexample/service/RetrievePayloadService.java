package com.geekcap.springintegrationexample.service;

public interface RetrievePayloadService
{
    public String getPayload( String id );
}
